from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    path('admin/', admin.site.urls),
    path('signup/', include('accounts.urls')),
    path('login/', include('accounts.urls')),
    path('contact/', include('accounts.urls')),

    # Redirect the root URL to login
    path('', lambda request: redirect('login')),  # Redirect root to login page
]
